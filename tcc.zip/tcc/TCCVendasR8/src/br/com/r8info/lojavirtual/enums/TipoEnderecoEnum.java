package br.com.r8info.lojavirtual.enums;

public enum TipoEnderecoEnum {
	RESIDENCIAL,
	COMERCIAL, 
	CORRESPONDENCIA, 
	ENTREGA;
}
package br.com.r8info.lojavirtual.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import br.com.r8info.lojavirtual.common.model.BaseORM;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@Entity
@Table(name = "TBL_CATEGORIA")
public class Categoria extends BaseORM {
	@Id
	@TableGenerator(name = "SQ_CATEGORIA", table = "APP_SEQ_STORE", pkColumnName = "APP_SEQ_NAME", pkColumnValue = "SQ_CATEGORIA", valueColumnName = "APP_SEQ_VALUE", initialValue = 1, allocationSize = 1)
	@Column(name="ID_CATEGORIA")
	private Long id;
	
	@Column(name="TX_NOME")
	private String nome;	
	
	@Column(name="DS_CATEGORIA")
	private String descricao;
	
	
	
}

package br.com.r8info.lojavirtual.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import br.com.r8info.lojavirtual.common.model.BaseORM;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
// @Entity
@Table(name = "USUARIO")
public class Usuario extends BaseORM {

	@Id
	@TableGenerator(name = "SQ_USUARIO", table = "APP_SEQ_STORE", pkColumnName = "APP_SEQ_NAME", pkColumnValue = "SQ_USUARIO", valueColumnName = "APP_SEQ_VALUE", initialValue = 1, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "SQ_USUARIO")
	@Column(name = "")
	private Long id;

	@Column(name = "ID_USUARIO")
	private String login;

	@Column(name = "SE_USUARIO")
	private String senha;

	@Column(name = "QT_USUARIO")
	private int quantidadeAcesso;

	@Column(name = "DC_USUARIO")
	private Date dataCriacao;

	@Column(name = "DT_USUARIO")
	private Date dataValidadeUsuario;

	@Column(name = "DV_USUARIO")
	private Date dataValidadeSenha;

}
package br.com.r8info.lojavirtual.business;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.r8info.lojavirtual.common.business.BaseSB;
import br.com.r8info.lojavirtual.dao.CategoriaDAO;
import br.com.r8info.lojavirtual.model.Categoria;

@Service
public class CategoriaSB extends BaseSB {
	private CategoriaDAO categoriaDAO;

	@Override
	protected void postConstructImpl() {
		categoriaDAO = getDAO(CategoriaDAO.class);
	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List<Categoria> findAll() {
		return categoriaDAO.findAll();
	}

}

package br.com.r8info.lojavirtual.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import br.com.r8info.lojavirtual.common.model.BaseORM;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
//@Entity
@Table(name = "TBL_COMPRA")
public class Compra extends BaseORM {

	@Id
	@TableGenerator(name = "SQ_COMPRA", table = "APP_SEQ_STORE", pkColumnName = "APP_SEQ_NAME", pkColumnValue = "SQ_COMPRA", valueColumnName = "APP_SEQ_VALUE", initialValue = 1, allocationSize = 1)
	@Column(name = "ID_COMPRA")
	private Long id;

	@Column(name = "NM_PARCELAS")
	private int numeroParcelas;

	@Column(name = "TX_DESCRICAO")
	private String descricaoCompra;

	@Column(name = "DT_PAGAMENTO")
	private Date dataPgto;

	@Column(name = "VL_PAGO")
	private double valorPago;

}
package br.com.r8info.lojavirtual.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import br.com.r8info.lojavirtual.common.model.BaseORM;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
//@Entity
@Table(name = "TBL_CARRINHO")
public class Carrinho extends BaseORM {

	@Id
	@TableGenerator(name = "SQ_CARRINHO", table = "APP_SEQ_STORE", pkColumnName = "APP_SEQ_NAME", pkColumnValue = "SQ_CARRINHO", valueColumnName = "APP_SEQ_VALUE", initialValue = 1, allocationSize = 1)
	@Column(name = "ID_CARRINHO")
	private Long id;

	@Column(name = "DT_CARRINHO")
	private Date data;

	@Column(name = "VD_CARRINHO")
	private int validadeCarrinho;

	@Column(name = "VL_CARRINHO")
	private float valorCarrinho;

	@Column(name = "DC_CARRINHO")
	private float descontoCarrinho;

	@Column(name = "VL_FRETE")
	private float valorFrete;

}

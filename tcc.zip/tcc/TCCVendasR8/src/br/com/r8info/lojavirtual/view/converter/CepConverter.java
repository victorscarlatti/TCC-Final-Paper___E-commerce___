package br.com.r8info.lojavirtual.view.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

@FacesConverter("cepConverter")
public class CepConverter implements Converter {

	public Object getAsObject(FacesContext arg0, UIComponent arg1, String value) {
		String cep = value;
		if (cep != null && !cep.equals("")) {
			cep = value.replaceAll("[^0-9]", "");
		}
		return cep;
	}

	public String getAsString(FacesContext arg0, UIComponent arg1, Object value) {
		String cep = String.valueOf(value);
		if (cep != null && cep.length() == 8) {
			cep = cep.substring(0, 5) + "-" + cep.substring(5);
		}
		return cep;
	}

}

package br.com.r8info.lojavirtual.report;

import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import br.com.caelum.stella.boleto.Boleto;
import br.com.caelum.stella.boleto.exception.GeracaoBoletoException;
import br.com.caelum.stella.boleto.transformer.GeradorDeBoleto;

public class GeradorBoletoCustom extends GeradorDeBoleto {

	public GeradorBoletoCustom(Boleto... boletos) {
		super(boletos);
	}

	public JasperPrint geraRelatorio() {
		try {
			if (relatorio == null) {
				JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(
						boletos);
				relatorio = JasperFillManager.fillReport(templateJasper,
						parametros, dataSource);
			}
			return relatorio;
		} catch (Exception e) {
			throw new GeracaoBoletoException(e);
		}
	}

}
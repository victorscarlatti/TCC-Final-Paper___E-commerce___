package br.com.r8info.lojavirtual.business;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.r8info.lojavirtual.business.exception.UsuarioException;
import br.com.r8info.lojavirtual.business.exception.UsuarioException.MESSAGE_USUARIO;
import br.com.r8info.lojavirtual.common.business.BaseSB;
import br.com.r8info.lojavirtual.dao.PessoaDAO;
import br.com.r8info.lojavirtual.enums.TipoPessoaEnum;
import br.com.r8info.lojavirtual.model.Pessoa;
import br.com.r8info.lojavirtual.model.Produto;
import br.com.r8info.lojavirtual.security.business.utils.PasswordUtils;

@Service
public class PessoaSB extends BaseSB {
	
	public PessoaDAO pessoaDAO;

	@Override
	protected void postConstructImpl() {
		pessoaDAO = getDAO(PessoaDAO.class);
	}
	
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List<Pessoa> findAll() {
		return pessoaDAO.findAll();
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	public void insertCliente(Pessoa pessoa) throws UsuarioException {
		Pessoa existente = pessoaDAO.findByEmailOrCpfCnpj(pessoa.getEmail(), pessoa.getCpfCnpj());
		if (existente!= null){
			throw new UsuarioException(MESSAGE_USUARIO.USUARIO_EXISTENTE);
		}
		String senhaCriptografada = PasswordUtils.criptografarMD5(pessoa.getSenha());
		pessoa.setSenha(senhaCriptografada);
		pessoa.setTipo(TipoPessoaEnum.CLIENTE);
		pessoaDAO.save(pessoa);
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	public void insert(Pessoa pessoa) throws UsuarioException {
		Pessoa existente = pessoaDAO.findByEmailOrCpfCnpj(pessoa.getEmail(), pessoa.getCpfCnpj());
		if (existente!= null){
			throw new UsuarioException(MESSAGE_USUARIO.USUARIO_EXISTENTE);
		}
		String senhaCriptografada = PasswordUtils.criptografarMD5(pessoa.getSenha());
		pessoa.setSenha(senhaCriptografada);
		pessoaDAO.save(pessoa);
	}
	
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public Pessoa findById(Long id) {
		return pessoaDAO.findOne(id);
	}

}

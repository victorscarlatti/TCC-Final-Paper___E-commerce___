package br.com.r8info.lojavirtual.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import br.com.r8info.lojavirtual.common.model.BaseORM;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
//@Entity
@Table(name = "TBL_CARRINHO_PRODUTO")
public class CarrinhoProdutos extends BaseORM {

	@Id
	@TableGenerator(name = "SQ_CARRINHO_PRODUTOS", table = "APP_SEQ_STORE", pkColumnName = "APP_SEQ_NAME", pkColumnValue = "SQ_CARRINHO_PRODUTO", valueColumnName = "APP_SEQ_VALUE", initialValue = 1, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "SQ_CARRINHO_PRODUTOS")
	@Column(name = "ID_PRODUTO")
	private Long id;

	@Column(name = "QT_PRODUTO")
	private Integer quantidadeProdutoCarrinho;

	@Column(name = "VL_VENDA")
	private double valorVendaProduto;
}

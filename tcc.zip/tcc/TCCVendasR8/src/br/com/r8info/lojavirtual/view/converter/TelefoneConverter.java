package br.com.r8info.lojavirtual.view.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

@FacesConverter("telefoneConverter")
public class TelefoneConverter implements Converter {

	public Object getAsObject(FacesContext arg0, UIComponent arg1, String value) {
		String tel = value;

		if (tel != null && !tel.equals("")) {
			tel = value.replaceAll("[^0-9]", "");
		}

		return tel;
	}

	public String getAsString(FacesContext arg0, UIComponent arg1, Object value) {
		String tel = String.valueOf(value);
		if (tel != null && tel.length() == 10) {
			tel = "(" + tel.substring(0, 2) + ")" + tel.substring(2, 6) + "-"
					+ tel.substring(6);
		}
		return tel;
	}

}

package br.com.r8info.lojavirtual.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import br.com.r8info.lojavirtual.common.model.BaseORM;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
//@Entity
@Table(name = "TBL_ITEM_COMPRA")
public class ItemCompra extends BaseORM {

	@Id
	@TableGenerator(name = "SQ_ITEM_COMPRA", table = "APP_SEQ_STORE", pkColumnName = "APP_SEQ_NAME", pkColumnValue = "SQ_ITEM_COMPRA", valueColumnName = "APP_SEQ_VALUE", initialValue = 1, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "SQ_ITEM_COMPRA")
	@Column(name = "ID_COMPRA")
	private Long id;

	@Column(name = "QT_COMPRA")
	private int quantidadeCompraProduto;

	@Column(name = "VL_COMPRA")
	private double valorCompraProduto;
}
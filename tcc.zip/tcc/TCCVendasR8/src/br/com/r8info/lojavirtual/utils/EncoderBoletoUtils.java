package br.com.r8info.lojavirtual.utils;

import javax.xml.bind.DatatypeConverter;

public class EncoderBoletoUtils {

	public static String encoder(Long value) {
		if (value == null) {
			return null;
		}
		String strValue = value.toString();
		return DatatypeConverter.printBase64Binary(strValue.getBytes());
	}

	public static Long decoder(String value) {
		if (value == null) {
			return null;
		}
		String decoded = new String(DatatypeConverter.parseBase64Binary(value));
		return new Long(decoded);
	}

}

package br.com.r8info.lojavirtual.view;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import br.com.r8info.lojavirtual.model.Carrinho;
import br.com.r8info.lojavirtual.model.Categoria;
import br.com.r8info.lojavirtual.model.Foto;
import br.com.r8info.lojavirtual.model.Pessoa;
import br.com.r8info.lojavirtual.model.Produto;

public class TesteProduto {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PC2-MYSQL");
		EntityManager em = emf.createEntityManager();
		
		
		em.find(Pessoa.class, 1L);
	}
}

package br.com.r8info.lojavirtual.business;

import org.springframework.stereotype.Service;

import br.com.r8info.lojavirtual.common.business.BaseSB;

@Service
public class ContratoSB extends BaseSB {

	@Override
	protected void postConstructImpl() {
		// TODO Auto-generated method stub
		
	}

}

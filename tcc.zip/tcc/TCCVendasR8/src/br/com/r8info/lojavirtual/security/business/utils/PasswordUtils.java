package br.com.r8info.lojavirtual.security.business.utils;

import org.springframework.util.DigestUtils;

public class PasswordUtils {

	public static String criptografarMD5(String senha) {
		return senha != null ? DigestUtils.md5DigestAsHex(senha.getBytes())
				: null;
	}
}

package br.com.r8info.lojavirtual.dao;

import org.springframework.stereotype.Repository;

import br.com.r8info.lojavirtual.common.dao.BaseDAO;
import br.com.r8info.lojavirtual.dao.custom.ProdutoDAOCustom;
import br.com.r8info.lojavirtual.model.Produto;

@Repository
public interface ProdutoDAO extends BaseDAO<Produto>, ProdutoDAOCustom {
	
}
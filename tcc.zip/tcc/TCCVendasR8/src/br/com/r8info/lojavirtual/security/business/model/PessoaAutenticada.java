package br.com.r8info.lojavirtual.security.business.model;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import lombok.Getter;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import br.com.r8info.lojavirtual.enums.TipoPessoaEnum;

@Getter
public class PessoaAutenticada implements UserDetails {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2637025534726845541L;
	
	private String email;
	private String senha;
	private String cpf;
	private Long id;
	private TipoPessoaEnum tipoPessoa;
	private Set<GrantedAuthority> authorities = new HashSet<GrantedAuthority>();
	private boolean enable = true;

	public PessoaAutenticada(Long id, 
							 String email, 
							 String cpf,
							 TipoPessoaEnum tipoPessoa,
							 Collection<? extends GrantedAuthority> authorities) {
		this.id = id;
		this.email = email;
		this.cpf = cpf;
		this.tipoPessoa = tipoPessoa;
		this.authorities.addAll(authorities);
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return authorities;
	}

	@Override
	public String getPassword() {
		return senha;
	}

	@Override
	public String getUsername() {
		return email;
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return false;
	}

	public Long getId() {
		return id;
	}

	public String getCpf() {
		return cpf;
	}

	public boolean hasRole(String role) {
		for (GrantedAuthority grant : getAuthorities()) {
			if (grant.getAuthority().equals(role)) {
				return true;
			}
		}
		return false;
	}

}

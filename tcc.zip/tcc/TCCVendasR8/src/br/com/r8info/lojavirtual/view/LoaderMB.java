package br.com.r8info.lojavirtual.view;

import java.util.List;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import br.com.r8info.lojavirtual.business.CategoriaSB;
import br.com.r8info.lojavirtual.model.Categoria;

@Controller
@ManagedBean
@ApplicationScoped
public class LoaderMB {
	
	@Autowired
	private CategoriaSB categoriaSB;
	
	public List<Categoria> getCategoria(){
		return categoriaSB.findAll();
	}

}

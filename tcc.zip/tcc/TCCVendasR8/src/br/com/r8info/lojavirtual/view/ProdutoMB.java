package br.com.r8info.lojavirtual.view;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

import lombok.Getter;
import lombok.Setter;

import org.apache.commons.io.FilenameUtils;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import br.com.r8info.lojavirtual.business.ProdutoSB;
import br.com.r8info.lojavirtual.business.exception.FalhaGravacaoImagemException;
import br.com.r8info.lojavirtual.common.view.BaseMB;
import br.com.r8info.lojavirtual.model.Foto;
import br.com.r8info.lojavirtual.model.Produto;

@Getter
@Setter
@ManagedBean
@Controller
public class ProdutoMB extends BaseMB {

	@Autowired
	private ProdutoSB produtoSB;

	private List<Produto> produtos;

	@Autowired
	private Produto edit;

	public void doAtualizarProdutos() {
		produtos = produtoSB.findAll();
	}

	public void doIncluirFoto(FileUploadEvent event) {
		FacesContext context = FacesContext.getCurrentInstance();
		try {
			UploadedFile file = event.getFile();
			Foto anexo = new Foto();
			anexo.setNome(FilenameUtils.getName(file.getFileName()));
			anexo.setInputStream(file.getInputstream());
			anexo.setCaminho(getPathImage());
			edit.setFoto(anexo);
		} catch (FileNotFoundException e) {
			context.addMessage(null, new FacesMessage(e.getMessage()));
		} catch (IOException e) {
			context.addMessage(null, new FacesMessage(e.getMessage()));
		}
	}

	public void doSave() {
		try {
			if (edit.getFoto() != null) {
				produtoSB.insert(edit);
				showInsertMessage();
			} else {
				showErrorMessage("Foto n�o selecionada");
				validationFailed();
			}
		} catch (FalhaGravacaoImagemException e) {
			showErrorMessage(e.getMessage());
			validationFailed();
		}
	}
	
	public void doPrepareSave(){
		edit = new Produto();
	}
	
	
}

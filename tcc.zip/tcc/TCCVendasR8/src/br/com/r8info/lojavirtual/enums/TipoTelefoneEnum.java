package br.com.r8info.lojavirtual.enums;

public enum TipoTelefoneEnum {
	CELULAR, 
	RESIDENCIAL, 
	COMERCIAL, 
	RECADO, 
	FAX;
}
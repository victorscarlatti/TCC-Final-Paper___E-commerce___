package br.com.r8info.lojavirtual.view;

import javax.faces.bean.ManagedBean;

import lombok.Getter;
import lombok.Setter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import br.com.r8info.lojavirtual.business.PessoaSB;
import br.com.r8info.lojavirtual.common.view.BaseMB;
import br.com.r8info.lojavirtual.model.Pessoa;


@Getter
@Setter
@ManagedBean
@Controller
public class MinhaContaMB extends BaseMB {
	
	@Autowired
	private PessoaSB pessoaSB;
	
	@Autowired
	private Pessoa edit;
	
	public void doPrepareLoad(){
		if (getCurrentUser() != null) {
			edit = pessoaSB.findById(getCurrentUser().getId());
		}
	 }
}

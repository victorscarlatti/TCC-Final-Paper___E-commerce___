package br.com.r8info.lojavirtual.view;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import lombok.Getter;
import lombok.Setter;

import org.springframework.stereotype.Controller;

import br.com.etechoracio.report.view.utils.URLEncoder;
import br.com.r8info.lojavirtual.common.view.BaseMB;
import br.com.r8info.lojavirtual.security.business.utils.PasswordUtils;

@Getter
@Setter
@ViewScoped
@Controller
@ManagedBean
public class BoletoMB extends BaseMB{
	
	private URLEncoder urlEncoder = new URLEncoder();

	/**
	 * Evento de clique no bot�o "Exportar PDF".
	 * 
	 * @return Endere�o de execu��o do relat�rio
	 */
	public String buildReportUrlPdf() {
		Long id = 100L;
		String uid = PasswordUtils.criptografarMD5(id.toString());
		return urlEncoder.format("boleto", "uid", uid);
	}	
}
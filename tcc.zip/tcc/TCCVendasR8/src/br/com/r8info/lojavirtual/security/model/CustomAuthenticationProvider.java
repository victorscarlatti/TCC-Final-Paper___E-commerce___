package br.com.r8info.lojavirtual.security.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Controller;

import br.com.r8info.lojavirtual.business.AcessoSB;
import br.com.r8info.lojavirtual.security.business.exception.PessoaNaoAutenticadoException;
import br.com.r8info.lojavirtual.security.business.model.PessoaAutenticada;

@Controller
public class CustomAuthenticationProvider implements AuthenticationProvider {

	@Autowired
	private AcessoSB acessoSB;
		
	@Override
	public Authentication authenticate(Authentication authentication)
			throws AuthenticationException {
		try {
			PessoaAutenticada pessoa = acessoSB.autenticar(
					(String) authentication.getPrincipal(),
					(String) authentication.getCredentials());
			return new UsernamePasswordAuthenticationToken(pessoa,
					pessoa.getPassword(), pessoa.getAuthorities());
		} catch (PessoaNaoAutenticadoException e) {
			throw new BadCredentialsException(e.getMessage());
		}
	}

	@Override
	public boolean supports(Class<? extends Object> arg0) {
		return arg0.equals(UsernamePasswordAuthenticationToken.class);
	}

}

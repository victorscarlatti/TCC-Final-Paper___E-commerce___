package br.com.r8info.lojavirtual.view.converter;

import java.util.Map;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import br.com.r8info.lojavirtual.common.model.BaseORM;

/**
 * FACES CONVERTER p/ Entity.
 * 
 * @author Rog�rio de Morais
 */
@FacesConverter(value = "entityConverter")
public class EntityConverter implements Converter {

	@Override
	public Object getAsObject(FacesContext context, UIComponent component,
			String value) {
		if (value != null) {
			return this.getAttributesFrom(component).get(value);
		}
		return null;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component,
			Object value) {
		if (value != null && !"".equals(value)) {

			BaseORM entity = (BaseORM) value;

			if (entity.getId() == null) {
				return "";
			}

			this.addAttribute(component, entity);

			Long id = (Long) entity.getId();
			if (id != null) {
				return String.valueOf(id);
			}
		}
		return (String) value;
	}

	/**
	 * @param component
	 * @param o
	 */
	protected void addAttribute(UIComponent component, BaseORM o) {
		String key = o.getId().toString(); 
		this.getAttributesFrom(component).put(key, o);
	}

	/**
	 * @param component
	 * @return
	 */
	protected Map<String, Object> getAttributesFrom(UIComponent component) {
		return component.getAttributes();
	}

}

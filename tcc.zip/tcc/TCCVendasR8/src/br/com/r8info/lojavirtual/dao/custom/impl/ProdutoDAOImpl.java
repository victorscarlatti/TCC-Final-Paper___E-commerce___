package br.com.r8info.lojavirtual.dao.custom.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import br.com.r8info.lojavirtual.common.dao.BaseDAOCustom;
import br.com.r8info.lojavirtual.dao.custom.ProdutoDAOCustom;
import br.com.r8info.lojavirtual.enums.TipoBuscaEnum;
import br.com.r8info.lojavirtual.model.Produto;

public class ProdutoDAOImpl extends BaseDAOCustom implements ProdutoDAOCustom {

	public ProdutoDAOImpl(EntityManager em) {
		super(em);		
	}

	@Override
	public List<Produto> findAllOrderBy(TipoBuscaEnum tipo) {
		StringBuilder jpql = new StringBuilder();
		jpql.append("SELECT p FROM Produto p ");
		
		if(tipo != null){
			jpql.append(tipo.getJpqlOrderBy());
		}
		
		TypedQuery<Produto> query = getEntityManager().createQuery(jpql.toString(), Produto.class);
		
		return query.getResultList();
	}

}

package br.com.r8info.lojavirtual.view;

import java.util.Arrays;
import java.util.List;

import javax.faces.bean.ManagedBean;

import lombok.Getter;
import lombok.Setter;

import org.primefaces.model.StreamedContent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import br.com.r8info.lojavirtual.business.ProdutoSB;
import br.com.r8info.lojavirtual.common.view.BaseMB;
import br.com.r8info.lojavirtual.enums.TipoBuscaEnum;
import br.com.r8info.lojavirtual.model.Produto;
import br.com.r8info.lojavirtual.utils.ImageUtils;

@Getter
@Setter
@ManagedBean
@Controller
public class ListaProdutoMB extends BaseMB {

	
	
	@Autowired
	private ProdutoSB produtoSB;

	private TipoBuscaEnum filtroTipoBusca;
	
	private List<Produto> produtos;
	
	private Produto edit;

	public void doAtualizarProdutos() {
		produtos = produtoSB.findAllOrderBy(filtroTipoBusca);
	}

	public StreamedContent getDynamicImage() {
		String url = String.format("%s\\%s", getPathImage(), NO_IMAGE);
		String foto = getExternalContext().getRequestParameterMap().get("image_name");
		if (foto != null && foto.length() > 0) {
			url = String.format("%s\\%s", getPathImage(), foto);
		}
		return ImageUtils.getDefaultStreamedContent(url);
	}

	public void doPrepareView(Produto produto) {
		edit=produtoSB.findByCodigo(produto.getId());
		redirect(CONTEXT_PAGES+"/descricao.xhtml");
	}
	
	public StreamedContent getEditImage() {
		String url = String.format("%s\\%s", getPathImage(), NO_IMAGE);
		if (edit.getFoto() != null) {
			url = String.format("%s\\%s", getPathImage(), edit.getFoto().getNome());
		}
		return ImageUtils.getDefaultStreamedContent(url);
	}
	
	public void doChangeTipoBusca(){
		produtos = produtoSB.findAllOrderBy(filtroTipoBusca);
	}
	
	public List<TipoBuscaEnum> getTiposFiltro(){
		return Arrays.asList(TipoBuscaEnum.values());
	}
}

package br.com.r8info.lojavirtual.common.dao;


import javax.persistence.EntityManager;

/**
 * Classe BASE para todos os DAOs customizados da aplica��o.
 * 
 * @author Rog�rio de Morais
 * 
 */
public abstract class BaseDAOCustom {

    private EntityManager em = null;

    public BaseDAOCustom(EntityManager em) {
        if (em == null) {
            throw new RuntimeException("EntityManager cannot be null!!");
        }
        this.em = em;
    }

    public final EntityManager getEntityManager() {
        return em;
    }
  
 }

package br.com.r8info.lojavirtual.enums;

import lombok.Getter;

@Getter
public enum TipoBuscaEnum {

	POR_NOME("Nome", "ORDER BY p.nome"),
	MAIOR_PRECO("Maior pre�o", "ORDER BY p.valorVenda DESC"),
	MENOR_PRECO("Menor pre�o", "ORDER BY p.valorVenda ASC");
	
	private String label;
	private String jpqlOrderBy;
	
	TipoBuscaEnum(String label, String jpqlOrderBy) {
		this.label = label;
		this.jpqlOrderBy = jpqlOrderBy;
	}
	
	
}

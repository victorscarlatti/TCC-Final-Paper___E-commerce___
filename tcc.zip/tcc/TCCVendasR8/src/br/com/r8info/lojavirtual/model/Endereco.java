package br.com.r8info.lojavirtual.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import lombok.Getter;
import lombok.Setter;
import br.com.r8info.lojavirtual.common.model.BaseORM;
import br.com.r8info.lojavirtual.enums.TipoEnderecoEnum;

@Getter
@Setter
@Entity
@Table(name = "TBL_ENDERECO")
public class Endereco extends BaseORM {

	@Id
	@TableGenerator(name = "SQ_ENDERECO", table = "APP_SEQ_STORE", pkColumnName = "APP_SEQ_NAME", pkColumnValue = "SQ_ENDERECO", valueColumnName = "APP_SEQ_VALUE", initialValue = 1, allocationSize = 1)
	@Column(name = "ID_ENDERECO")
	private Long id;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_PESSOA")
	private Pessoa pessoa;
	
	@Column(name="ID_TIPO_ENDERECO")
	@Enumerated(EnumType.ORDINAL)
	private TipoEnderecoEnum tipoEndereco;
		
	@Column(name = "TX_ENDERECO")
	private String endereco;
	
	@Column(name = "NR_ENDERECO")
	private String numero;
	
	@Column(name = "TX_COMPLEMENTO")
	private String complemento;
	
	@Column(name = "TX_BAIRRO")
	private String bairro;
	
	@Column(name = "TX_CEP")
	private String cep;
	
	@Column(name = "TX_CIDADE")
	private String cidade;
	
	@Column(name = "TX_UF")
	private String uf;
}
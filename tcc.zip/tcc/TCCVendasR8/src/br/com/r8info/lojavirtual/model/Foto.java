package br.com.r8info.lojavirtual.model;

import java.io.InputStream;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;
import br.com.r8info.lojavirtual.common.model.BaseORM;


@Getter
@Setter
@Entity
@Table(name = "TBL_FOTO")
public class Foto extends BaseORM {
	
	@Id
	@TableGenerator(name = "SQ_FOTO", table = "APP_SEQ_STORE", pkColumnName = "APP_SEQ_NAME", pkColumnValue = "SQ_FOTO", valueColumnName = "APP_SEQ_VALUE", initialValue = 1000, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "SQ_FOTO")
	@Column(name="ID_FOTO")
	private Long id;
	
	@Column(name="TX_NOME")
	private String nome;
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_PRODUTO")
	private Produto produto;
	
	@Transient
	private InputStream inputStream;
	
	@Transient
	private String caminho;
	
}

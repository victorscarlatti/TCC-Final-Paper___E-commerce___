package br.com.r8info.lojavirtual.security.model;

import org.springframework.security.core.GrantedAuthority;

import br.com.r8info.lojavirtual.enums.TipoPessoaEnum;

@SuppressWarnings("serial")
public class RoleAuthority implements GrantedAuthority {
	
	private TipoPessoaEnum tipoPessoa;

	public RoleAuthority(TipoPessoaEnum tipoPessoa) {
		super();
		this.tipoPessoa = tipoPessoa;
	}

	@Override
	public String getAuthority() {
		return tipoPessoa.name();
	}

}

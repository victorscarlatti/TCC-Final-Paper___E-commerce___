package br.com.r8info.lojavirtual.view;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import lombok.Getter;
import lombok.Setter;

import org.springframework.stereotype.Controller;

import br.com.r8info.lojavirtual.common.view.BaseMB;
import br.com.r8info.lojavirtual.model.ItemVenda;
import br.com.r8info.lojavirtual.model.Produto;
import br.com.r8info.lojavirtual.model.Usuario;
import br.com.r8info.lojavirtual.model.Venda;

@ManagedBean
@SessionScoped
@Getter
@Setter
@Controller
public class CarrinhoMB extends BaseMB{
	
	private Venda vendaCarrinho;
	private Usuario usuario;
	private Long idPedidoGerado;
	
	
	public String doAdicionarItem(Produto produto) {
		vendaCarrinho.adicionarItens(produto, 1);
		return "carrinho?faces-redirect=true";
	  }
	
	public String doContCompra() {
		return "produtos?faces-redirect=true";
	  }
	@PostConstruct
	public void init() {
		vendaCarrinho = new Venda();
		usuario = new Usuario();
	}

	public String adicionarItem(Produto produto) {
		vendaCarrinho.adicionarItens(produto, 1);
		return "carrinho?faces-redirect=true";
	}

	public void removerItem(Produto produtoRemover) {
		vendaCarrinho.removerItem(produtoRemover);
	}

	public void atualizarQuantidadeItem(ItemVenda itemVenda, int novaQuantidade) {
		vendaCarrinho.atualizarQuantidade(itemVenda, novaQuantidade);
	}

	public String fecharPedidoUsuarioExistente() {
		return fecharPedido();
	}

	public String fecharPedidoNovoUsuario() {
		return fecharPedido();
	}

	public String fecharPedido() {
		return "interno/pedido-fechado?faces-redirect=true";
	}

	public void recalcularTotal(ItemVenda itemVenda) {
		itemVenda.calcularTotal();
		vendaCarrinho.calcularTotal();
	}

	public boolean temItens() {
		return vendaCarrinho.getItens().size() > 0;
	}
	
}
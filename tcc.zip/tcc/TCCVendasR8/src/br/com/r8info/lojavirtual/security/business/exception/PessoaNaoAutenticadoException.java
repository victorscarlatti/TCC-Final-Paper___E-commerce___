package br.com.r8info.lojavirtual.security.business.exception;

public class PessoaNaoAutenticadoException extends Exception {
	public PessoaNaoAutenticadoException(){
		super("Usu�rio ou senha inv�lida.");
	}
}

package br.com.r8info.lojavirtual.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Transient;

import br.com.r8info.lojavirtual.common.model.BaseORM;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "TBL_ITEM_VENDA")
public class ItemVenda extends BaseORM {

	@Id
	@TableGenerator(name = "SQ_ITEM_VENDA", table = "APP_SEQ_STORE", pkColumnName = "APP_SEQ_NAME", pkColumnValue = "SQ_ITEM_VENDA", valueColumnName = "APP_SEQ_VALUE", initialValue = 1, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "SQ_ITEM_VENDA")
	@Column(name = "ID_ITEM_VENDA")
	private Long id;

	@ManyToOne
	@JoinColumn(name="ID_VENDA")
	private Venda venda;
	
	@ManyToOne
	@JoinColumn(name="ID_PRODUTO")
	private Produto produto;
	
	@Column(name = "QT_PRODUTO")
	private int quantidade;
	
	@Transient
	@Column(name = "VL_UNITARIO")
	private double valorUnitario;

	@Transient
	@Column(name = "VL_ICMS")
	private double icmsVendaProduto;
	
	@Transient
	private double subtotal;
	
	public ItemVenda() {}

	public ItemVenda(Produto produto) {
		this.produto = produto;
	}

	public ItemVenda(Produto produto, int quantidade) {
		this.produto = produto;
		this.valorUnitario = produto.getValorVenda();
		this.quantidade = quantidade;
		calcularTotal();
	}

	public void calcularTotal() {
		subtotal = valorUnitario * quantidade;
	}

	public void atualizarQuantidade(Integer novaQuantidade) {
		this.quantidade = novaQuantidade;
		calcularTotal();
	}

	public Long getIdProduto() {
		return produto != null ? produto.getId() : null;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((produto == null) ? 0 : produto.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ItemVenda other = (ItemVenda) obj;
		if (produto == null) {
			if (other.produto != null)
				return false;
		} else if (!produto.equals(other.produto))
			return false;
		return true;
	}

}
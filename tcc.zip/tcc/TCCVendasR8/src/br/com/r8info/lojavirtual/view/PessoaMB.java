package br.com.r8info.lojavirtual.view;

import java.util.Arrays;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import lombok.Getter;
import lombok.Setter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import br.com.r8info.lojavirtual.business.PessoaSB;
import br.com.r8info.lojavirtual.business.exception.UsuarioException;
import br.com.r8info.lojavirtual.common.view.BaseMB;
import br.com.r8info.lojavirtual.enums.TipoPessoaEnum;
import br.com.r8info.lojavirtual.model.Pessoa;

@Getter
@Setter
@ManagedBean
@ViewScoped
@Controller
public class PessoaMB extends BaseMB {

	@Autowired
	private PessoaSB pessoaSB;
	
	@Autowired
	private Pessoa edit;

	private List<Pessoa> pessoa;
	
	private TipoPessoaEnum tipoPessoa;

	public void doAtualizarPessoa() {
		pessoa = pessoaSB.findAll();
	}	

	public List<TipoPessoaEnum> getTiposPessoa(){
		return Arrays.asList(TipoPessoaEnum.values());
	}
	
	public void doSave() {
		try {
			pessoaSB.insert(edit);
			showInsertMessage();
		} catch (UsuarioException e) {
			showErrorMessage(e.getMessage());
			validationFailed();
		}
	}
	
	public void doPrepareSave(){
		edit = new Pessoa();
	}

}

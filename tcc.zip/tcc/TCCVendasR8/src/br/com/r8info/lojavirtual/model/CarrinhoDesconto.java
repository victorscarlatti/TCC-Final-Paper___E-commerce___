package br.com.r8info.lojavirtual.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import br.com.r8info.lojavirtual.common.model.BaseORM;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
//@Entity
@Table(name = "CARRINHO_DESCONTO")
public class CarrinhoDesconto extends BaseORM {
	
	@Id
	@TableGenerator(name = "SQ_CARRINHO_DESCONTO", table = "APP_SEQ_STORE", pkColumnName = "APP_SEQ_NAME", pkColumnValue = "SQ_CARRINHO_DESCONTO", valueColumnName = "APP_SEQ_VALUE", initialValue = 1, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "SQ_CARRINHO_DESCONTO")
	@Column(name = "PL_DESCONTOCARRINHO")
	private Long id;
	
	@Column(name = "DT_DESCONTOCARRINHO")
	private Date dataDescontoCarrinho;
	
	@Column(name = "VD_DESCONTOCARRINHO")
	private int validadeDescontoCarrinho;
	
	@Column(name = "QT_DESCONTOCARRINHO")
	private int quantidadeDescontoCarrinho;
	
	@Column(name = "VL_TOTALCARRINHO")
	private double valorTotalCarrinho;
	
	@Column(name = "VL_DESCONTOCARRINHO")	
	private double valorDescontoCarrinho;
	
}

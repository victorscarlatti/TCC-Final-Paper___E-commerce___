package br.com.r8info.lojavirtual.enums;

public enum StatusVendaEnum {
	NAO_IDENTIFICADO,
	ANDAMENTO, 
	ORGANIZANDO, 
	DESPACHADO, 
	ENTREGUE, 
	FINALIZADO;
}
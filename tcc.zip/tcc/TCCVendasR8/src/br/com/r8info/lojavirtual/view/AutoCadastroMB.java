package br.com.r8info.lojavirtual.view;

import javax.faces.bean.ManagedBean;

import lombok.Getter;
import lombok.Setter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import br.com.r8info.lojavirtual.business.PessoaSB;
import br.com.r8info.lojavirtual.business.exception.UsuarioException;
import br.com.r8info.lojavirtual.common.view.BaseMB;
import br.com.r8info.lojavirtual.model.Pessoa;

@Getter
@Setter
@ManagedBean
@Controller
public class AutoCadastroMB extends BaseMB {

	@Autowired
	private PessoaSB pessoaSB;

	@Autowired
	private Pessoa pessoa;

	public void doClearPessoa() {
		pessoa = new Pessoa();
	}
	
	public void doSave() {
		try {
			pessoaSB.insertCliente(pessoa);
			redirect(PAGE_LOGIN + "?auto=true");
		} catch (UsuarioException e) {
			showErrorMessage(e.getMessage());
		}
	}
}

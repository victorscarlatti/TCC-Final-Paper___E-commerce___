package br.com.r8info.lojavirtual.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import lombok.Getter;
import lombok.Setter;

import org.springframework.stereotype.Component;

import br.com.r8info.lojavirtual.common.model.BaseORM;
import br.com.r8info.lojavirtual.enums.TipoPessoaEnum;

@Getter
@Setter
@Entity
@Table(name = "TBL_PESSOA")
@Component
public class Pessoa extends BaseORM {
	
	@Id
	@TableGenerator(name = "SQ_PESSOA", table = "APP_SEQ_STORE", pkColumnName = "APP_SEQ_NAME", pkColumnValue = "SQ_PESSOA", valueColumnName = "APP_SEQ_VALUE", initialValue = 1, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "SQ_PESSOA")
	@Column(name = "ID_PESSOA")
	private Long id;
	
	@Column(name = "TX_NOME")
	private String nome;
	
	@Column(name = "TX_SOBRENOME")
	private String sobrenome;
	
	@Column(name = "TX_CPF_CNPJ")
	private String cpfCnpj;
	
	@Column(name = "TX_EMAIL")
	private String email;
	
	@Column(name = "TX_SENHA")
	private String senha;
	
	@Column(name="ID_TIPO_PESSOA")
	@Enumerated(EnumType.ORDINAL)
	private TipoPessoaEnum tipo;
	
}
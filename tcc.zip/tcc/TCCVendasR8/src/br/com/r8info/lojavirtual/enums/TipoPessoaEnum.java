package br.com.r8info.lojavirtual.enums;

import lombok.Getter;

@Getter
public enum TipoPessoaEnum {
	DESCONHECIDO("Desconhecido"),
	CLIENTE("Cliente"), 
	FORNECEDOR("Fornecedor"), 
	FUNCIONARIO("Funcion�rio"), 
	COLABORADOR("Colaborador"), 
	ADMINISTRADOR("Administrador");
	
	private String label;
	
	TipoPessoaEnum(String label) {
		this.label = label;
	}
}
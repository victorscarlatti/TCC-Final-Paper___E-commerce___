package br.com.r8info.lojavirtual.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import lombok.Getter;
import lombok.Setter;

import org.springframework.stereotype.Component;

import br.com.r8info.lojavirtual.common.model.BaseORM;

@Getter
@Setter
@Entity
@Component
@Table(name = "TBL_PRODUTO")
public class Produto extends BaseORM {

	@Id
	@TableGenerator(name = "SQ_PRODUTO", table = "APP_SEQ_STORE", pkColumnName = "APP_SEQ_NAME", pkColumnValue = "SQ_PRODUTO", valueColumnName = "APP_SEQ_VALUE", initialValue = 1, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "SQ_PRODUTO")
	@Column(name = "ID_PRODUTO")
	private Long id;

	@Column(name = "TX_NOME")
	private String nome;

	@Column(name = "TX_DESCRICAO")
	private String descricao;

	@Column(name = "QT_PRODUTO")
	private int quantidade;
	
	@Column(name = "QT_MINIMA")
	private int quantidadeMinima;

	@Column(name = "VL_COMPRA")
	private float valorCompra;

	@Column(name = "VL_VENDA")
	private float valorVenda;

	@Column(name = "TX_STATUS")
	private String status;

	@Column(name = "VL_MINIMO")
	private float valorMinimo;

	@OneToOne(mappedBy="produto")
	private Foto foto;
	
	/*//TODO Remover ap�s cadastros no banco
	public Foto getFoto() {
		Foto f = new Foto();
		f.setNome("199465.jpg");
		return f;
	}*/
	
	@ManyToOne
	@JoinColumn(name="ID_CATEGORIA")
	private Categoria categoria;
	
	public Produto(){}
			
	public Produto(Long id) {
		this.id = id;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Produto other = (Produto) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}	
}
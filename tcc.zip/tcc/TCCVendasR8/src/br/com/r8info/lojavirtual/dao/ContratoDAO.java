package br.com.r8info.lojavirtual.dao;

import org.springframework.stereotype.Repository;

import br.com.r8info.lojavirtual.common.dao.BaseDAO;
import br.com.r8info.lojavirtual.model.Pessoa;

@Repository
public interface ContratoDAO extends BaseDAO<Pessoa> {

}

package br.com.r8info.lojavirtual.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import br.com.r8info.lojavirtual.common.model.BaseORM;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
//@Entity
@Table(name="VENDA_CLIENTE")
public class VendaCliente extends BaseORM {	
	@Id
	@TableGenerator(name = "SQ_VENDA_CLIENTE", table = "APP_SEQ_STORE", pkColumnName = "APP_SEQ_NAME", pkColumnValue = "SQ_VENDA_CLIENTE", valueColumnName = "APP_SEQ_VALUE", initialValue = 1, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "SQ_VENDA_CLIENTE")
	
	@Column(name="CD_VENDACLIENTE")
	private Long id;
	
	@Column(name = "")
	private String email;
	
	@Column(name="CC_VENDACLIENTE")
	private String CpfCnpjCliente;	
	
	@Column(name="NM_VENDACLIENTE")
	private String nomeCliente;	
	
	@Column(name="EN_VENDACLIENTE")
	private String enderecoCliente;	
	
	@Column(name="NR_ENVENDACLIENTE")
	private String numeroEndereco;	
	
	@Column(name="CM_ENVENDACLIENTE")
	private String complementoEndereco;	
	
	@Column(name="BA_ENVENDACLIENTE")
	private String bairroEndereco;	
	
	@Column(name="CP_ENVENDACLIENTE")
	private String cepEndereco;	
	
	@Column(name="CI_ENVENDACLIENTE")
	private String cidadeEndereco;	
	
	@Column(name="UF_ENVENDACLIENTE")
	private String ufEndereco;

}
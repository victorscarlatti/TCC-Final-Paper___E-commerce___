package br.com.r8info.lojavirtual.utils;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

import br.com.r8info.lojavirtual.business.exception.FalhaGravacaoImagemException;
import br.com.r8info.lojavirtual.business.exception.FalhaGravacaoImagemException.MESSAGE_FALHA_GRAVACAO_IMAGEM;

public class ImageUtils {

	
	public static StreamedContent getDefaultStreamedContent(String url) {
		try {
			File arquivoFoto = new File(url);
			FileInputStream fileInputStream = new FileInputStream(arquivoFoto);
			InputStream is = new BufferedInputStream(fileInputStream);
			return new DefaultStreamedContent(is);
		} catch (FileNotFoundException e) {
			return new DefaultStreamedContent();
		}
	}
	
	public static void salvarImagem(InputStream inputStream, String nomeArquivo, String localGravacao) throws FalhaGravacaoImagemException{
		try {
			File diretorio = new File(localGravacao);
			if (!diretorio.exists()) {
				diretorio.mkdir();
			}

			File file1 = new File(diretorio, nomeArquivo);
			FileOutputStream out = new FileOutputStream(file1);

			byte buf[] = new byte[1024];
			int len;
			while ((len = inputStream.read(buf)) > 0) {
				out.write(buf, 0, len);
			}
			inputStream.close();
			out.close();
		} catch (FileNotFoundException e) {
			throw new FalhaGravacaoImagemException(MESSAGE_FALHA_GRAVACAO_IMAGEM.ARQUIVO_NAO_ENCONTRADO);
		} catch (IOException e) {
			throw new FalhaGravacaoImagemException(MESSAGE_FALHA_GRAVACAO_IMAGEM.ERRO_INESPERADO);
		}
	}
	
}

package br.com.r8info.lojavirtual.report;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

import org.springframework.stereotype.Component;

import br.com.caelum.stella.boleto.Banco;
import br.com.caelum.stella.boleto.Beneficiario;
import br.com.caelum.stella.boleto.Boleto;
import br.com.caelum.stella.boleto.Datas;
import br.com.caelum.stella.boleto.Endereco;
import br.com.caelum.stella.boleto.Pagador;
import br.com.etechoracio.report.common.rest.BaseReportService;
import br.com.etechoracio.report.common.rest.JasperRunner.Type;
import br.com.r8info.lojavirtual.business.ProdutoSB;
import br.com.r8info.lojavirtual.model.Contrato;
import br.com.r8info.lojavirtual.model.Pessoa;

@Component
@Path("/jaxrs/boleto")
public class BoletoReportService extends BaseReportService {

	// @Autowired
	private ProdutoSB contratoSB;

	@GET
	public void print(@QueryParam("uid") String uid) {
		super.postConstruct();

		// String lngId = verificarDescriptografia

		Datas datas = getDatas();
		
		Endereco enderecoBeneficiario = buildEnderecoEmpresa();
		// Quem emite o boleto
		//TODO Pegar contrato do banco
		Beneficiario beneficiario = getBeneficiario(new Contrato(), 1L);

		Endereco enderecoPagador = getEnderecoCobranca(new br.com.r8info.lojavirtual.model.Endereco());
		// Quem paga o boleto
		Pagador pagador = getPagador(new Pessoa());

		//TODO Pegar tipo do banco
		Banco banco = getBanco(new Contrato());

		Boleto boleto = Boleto
				.novoBoleto()
				.comBanco(banco)
				.comDatas(datas)
				.comBeneficiario(beneficiario)
				.comPagador(pagador)
				.comValorBoleto("200.00")
				.comNumeroDoDocumento("1234")
				// ID da venda descriptografado
				.comInstrucoes("instrucao 1", "instrucao 2", "instrucao 3",
						"instrucao 4", "instrucao 5")
				.comLocaisDePagamento("local 1", "local 2");

		GeradorBoletoCustom custom = new GeradorBoletoCustom(boleto);

		this.jasperRunner.run(custom.geraRelatorio(), getServletResponse(),
				Type.PDF);
	}

	// TODO Verificar com a Chelsea o endere�o da empresa
	private Endereco buildEnderecoEmpresa() {
		return Endereco.novoEndereco().comLogradouro("Av das Empresas, 555")
				.comBairro("Bairro Grande").comCep("01234-555")
				.comCidade("S�o Paulo").comUf("SP");
	}

	private Endereco getEnderecoCobranca(br.com.r8info.lojavirtual.model.Endereco endereco) {
		if (endereco == null) {
			return null;
		}
		return Endereco.novoEndereco().comLogradouro(endereco.getEndereco())
				.comBairro(endereco.getBairro()).comCep(String.valueOf(endereco.getCep()))
				.comCidade(endereco.getCidade()).comUf(endereco.getUf());
	}

	public Beneficiario getBeneficiario(Contrato contrato, Long idVenda) {
		if (contrato == null) {
			return null;
		}
		return Beneficiario.novoBeneficiario()
				.comNomeBeneficiario(contrato.getNome())
				.comAgencia(String.valueOf(contrato.getAgencia()))
				.comDigitoAgencia(String.valueOf(contrato.getDigito()))
				.comCodigoBeneficiario(String.valueOf(contrato.getCodigo()))
				.comNumeroConvenio(String.valueOf(contrato.getConvenio()))
				.comCarteira(String.valueOf(contrato.getCarteira()));
	}

	public Pagador getPagador(Pessoa pessoa) {
		if (pessoa == null) {
			return null;
		}
		return Pagador.novoPagador().comDocumento(pessoa.getCpfCnpj())
				.comNome(pessoa.getNome());
	}

	public Banco getBanco(Contrato contrato) {
		if (contrato == null) {
			return null;
		}
		return contrato.getTipoBanco().getBanco();
	}

	public Datas getDatas() {
		return Datas.novasDatas();
	}
}
package br.com.r8info.lojavirtual.business.exception;


public class UsuarioException extends Exception {

	public static enum MESSAGE_USUARIO {
		USUARIO_EXISTENTE("Este usu�rio j� foi cadastrado.");

		public String message;

		MESSAGE_USUARIO(String message) {
			this.message = message;
		}
		

	}
	public UsuarioException(MESSAGE_USUARIO enumMessage) {
		super(enumMessage.message);
	}

}

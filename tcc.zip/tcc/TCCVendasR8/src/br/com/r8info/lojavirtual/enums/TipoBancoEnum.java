package br.com.r8info.lojavirtual.enums;

import br.com.caelum.stella.boleto.Banco;
import br.com.caelum.stella.boleto.bancos.BancoDoBrasil;
import br.com.caelum.stella.boleto.bancos.Bradesco;

public enum TipoBancoEnum {
	
	BANCO_BRASIL,
	BRADESCO;
	
	public Banco getBanco(){
		Banco resultado = null;
		switch (this) {
		case BANCO_BRASIL:
			resultado = new BancoDoBrasil();
			break;
		case BRADESCO:
			resultado = new Bradesco();
			break;
		default:
			resultado = null;
			break;
		}
		return resultado;
	}

}

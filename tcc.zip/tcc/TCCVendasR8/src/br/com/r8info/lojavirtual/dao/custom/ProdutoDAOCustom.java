package br.com.r8info.lojavirtual.dao.custom;

import java.util.List;

import br.com.r8info.lojavirtual.enums.TipoBuscaEnum;
import br.com.r8info.lojavirtual.model.Produto;

public interface ProdutoDAOCustom {

	
	public List<Produto> findAllOrderBy(TipoBuscaEnum tipo);
	
}

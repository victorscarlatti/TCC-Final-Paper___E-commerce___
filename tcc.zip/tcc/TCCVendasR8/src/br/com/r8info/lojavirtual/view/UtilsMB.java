package br.com.r8info.lojavirtual.view;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;

import br.com.etechoracio.report.view.utils.BaseUtilsMB;

/**
 * ManagedBean utilit�rio para as p�ginas do sistema.
 * 
 * <pre>
 * Last Modified  $Date: 2013/10/24 19:09:05 $
 * Last Modified by $Author: Rog�rio de Morais $
 * </pre>
 * 
 * @author Rog�rio de Morais
 * @version $Revision: 1.0 $
 */
@ManagedBean(name = "u")
@ApplicationScoped
public class UtilsMB extends BaseUtilsMB {

}

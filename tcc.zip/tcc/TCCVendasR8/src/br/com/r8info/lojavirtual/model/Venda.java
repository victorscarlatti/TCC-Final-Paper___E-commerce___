package br.com.r8info.lojavirtual.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;
import br.com.r8info.lojavirtual.common.model.BaseORM;
import br.com.r8info.lojavirtual.enums.StatusVendaEnum;
import br.com.r8info.lojavirtual.enums.TipoPagamentoEnum;

@Setter
@Getter
@Entity
@Table(name = "TBL_VENDA")
public class Venda extends BaseORM {

	@Id
	@TableGenerator(name = "SQ_VENDA", table = "APP_SEQ_STORE", pkColumnName = "APP_SEQ_NAME", pkColumnValue = "SQ_VENDA", valueColumnName = "APP_SEQ_VALUE", initialValue = 1, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "SQ_VENDA")
	@Column(name = "ID_VENDA")
	private Long id;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_PESSOA")
	private Pessoa pessoa;
	
	@Column(name="ID_TIPO_PGTO")
	@Enumerated(EnumType.ORDINAL)
	private TipoPagamentoEnum tipoPagamento;
	
	@Column(name="ID_STATUS_VENDA")
	@Enumerated(EnumType.ORDINAL)
	private StatusVendaEnum statusVenda;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ENDERECO_ENTREGA")
	private Endereco endereco;
	
	@Column(name = "DT_VENDA")
	private Date data;

	@OneToMany(mappedBy="venda")
	private Set<ItemVenda> itens;

	@Transient
	private double valorTotal;
	
	public Set<ItemVenda> getItens() {
		if (itens == null) {
			itens = new HashSet<ItemVenda>();
		}
		return itens;
	}

	public List<ItemVenda> getItensOrdenadosEmLista() {
		return new ArrayList<ItemVenda>(getItens());
	}

	public void adicionarItens(Produto produto, int quantidade) {
		ItemVenda itemExistente = getItem(produto);
		if (itemExistente != null) {
			atualizarQuantidade(itemExistente,
					itemExistente.getQuantidade() + quantidade);

		} else {
			getItens().add(new ItemVenda(produto, quantidade));
			calcularTotal();
		}
	}

	public void removerItem(Produto produto) {
		getItens().remove(new ItemVenda(produto));
		calcularTotal();
	}

	public ItemVenda getItem(Produto produto) {
		for (ItemVenda item : getItens()) {
			if (item.getIdProduto().equals(produto.getId())){
				return item;
			}
		}
		return null;
	}

	public void atualizarQuantidade(ItemVenda item, int novaQuantidade) {
		item.atualizarQuantidade(novaQuantidade);
		calcularTotal();
	}

	public void calcularTotal() {
		valorTotal = 0D;
		for (ItemVenda item : getItens()) {
			valorTotal += item.getSubtotal();
		}
	}

	public int getQuantidadeItens(){
		return getItens().size();
	}
}

package br.com.r8info.lojavirtual.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import br.com.r8info.lojavirtual.common.model.BaseORM;
import br.com.r8info.lojavirtual.enums.TipoBancoEnum;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
//@Entity
@Table(name = "TBL_CONTRATO2")
public class Contrato extends BaseORM {

	@Id
	@TableGenerator(name = "SQ_CONTRATO", table = "APP_SEQ_STORE", pkColumnName = "APP_SEQ_NAME", pkColumnValue = "SQ_CONTRATO", valueColumnName = "APP_SEQ_VALUE", initialValue = 1, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "SQ_CONTRATO")
	@Column(name = "ID_BENEFICIARIO")
	private Long id;
	
	@Column(name = "ID_TIPO_BANCO")
	private TipoBancoEnum tipoBanco;
	
	@Column(name = "TX_NOME")
	private String nome; 
	
	@Column(name = "NR_AGENCIA")
	private int agencia;
	
	@Column(name = "NR_DIGITO_AGENCIA")
	private int digito;
	
	@Column(name = "CD_BENEFICIARIO")
	private int codigo;
	
	@Column(name = "NR_CONVENIO")
	private int convenio;
	
	@Column(name = "NR_CARTEIRA")	
	private int carteira;
	
	@Column(name = "DT_INICIO_VIGENCIA")
	private Date inicio;
	
	@Column(name = "DT_FIM_VIGENCIA")
	private Date fim;
	
	@Column(name = "TX_INSTRUCAO")
	private String instrucao;
}


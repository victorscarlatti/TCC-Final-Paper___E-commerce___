package br.com.r8info.lojavirtual.business.exception;

public class FalhaGravacaoImagemException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8748814728568900224L;

	public static enum MESSAGE_FALHA_GRAVACAO_IMAGEM {
        ARQUIVO_NAO_ENCONTRADO("Arquivo n�o encontrado."),
        ERRO_INESPERADO("Erro inesperado na grava��o no disco.");

        public String message;

        MESSAGE_FALHA_GRAVACAO_IMAGEM(String message) {
            this.message = message;
        }
    }
	
	public FalhaGravacaoImagemException(MESSAGE_FALHA_GRAVACAO_IMAGEM enumMessage) {
		super(enumMessage.message);
	}
	
}

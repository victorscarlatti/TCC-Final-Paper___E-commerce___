package br.com.r8info.lojavirtual.business;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.r8info.lojavirtual.business.exception.FalhaGravacaoImagemException;
import br.com.r8info.lojavirtual.common.business.BaseSB;
import br.com.r8info.lojavirtual.dao.FotoDAO;
import br.com.r8info.lojavirtual.dao.ProdutoDAO;
import br.com.r8info.lojavirtual.enums.TipoBuscaEnum;
import br.com.r8info.lojavirtual.model.Foto;
import br.com.r8info.lojavirtual.model.Produto;
import br.com.r8info.lojavirtual.utils.ImageUtils;

@Service
public class ProdutoSB extends BaseSB {

	private ProdutoDAO produtoDAO;
	private FotoDAO fotoDAO;
	
	@Override
	protected void postConstructImpl() {
		produtoDAO = getDAO(ProdutoDAO.class);
		fotoDAO = getDAO(FotoDAO.class);
	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List<Produto> findAll() {
		return produtoDAO.findAll();
	}

	@Transactional(propagation = Propagation.REQUIRED, rollbackFor=FalhaGravacaoImagemException.class)
	public void insert(Produto produto) throws FalhaGravacaoImagemException {
		produtoDAO.save(produto);
		saveImage(produto.getId(), produto.getFoto());
	}
	
	private void saveImage(Long idProduto, Foto foto) throws FalhaGravacaoImagemException{
		ImageUtils.salvarImagem(foto.getInputStream(), foto.getNome(), foto.getCaminho());
		foto.setProduto(new Produto(idProduto));
		fotoDAO.save(foto);
	}
	
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public Produto findByCodigo(Long codigo) {
		return produtoDAO.findOne(codigo);
	}
	
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List<Produto> findAllOrderBy(TipoBuscaEnum tipo) {
		return produtoDAO.findAllOrderBy(tipo);
	}
}
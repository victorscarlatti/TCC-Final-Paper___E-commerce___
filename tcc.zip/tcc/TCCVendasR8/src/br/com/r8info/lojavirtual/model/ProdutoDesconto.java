package br.com.r8info.lojavirtual.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import br.com.r8info.lojavirtual.common.model.BaseORM;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
//@Entity
@Table(name = "TBL_PRODUTO_DESCONTO")
public class ProdutoDesconto extends BaseORM {

	@Id
	@TableGenerator(name = "SQ_PRODUTO_DESCONTO", table = "APP_SEQ_STORE", pkColumnName = "APP_SEQ_NAME", pkColumnValue = "SQ_PRODUTO_DESCONTO", valueColumnName = "APP_SEQ_VALUE", initialValue = 1, allocationSize = 1)
	@Column(name = "ID_DESCONTO")
	private Long id;

	@Column(name = "PD_PRODUTO")
	private int politicaProduto;

	@Column(name = "DT_INICIO_DESCONTO")
	private int DataInicioDesconto;

	@Column(name = "DT_FIM_DESCONTO")
	private int DataFimDesconto;
	
	@Column(name = "QT_DESCONTO")
	private int quantidadeDesconto;

	@Column(name = "VL_DESCONTO")
	private double valorDesconto;

}
package br.com.r8info.lojavirtual.business;

import java.util.HashSet;
import java.util.Set;

import org.springframework.stereotype.Service;

import br.com.r8info.lojavirtual.common.business.BaseSB;
import br.com.r8info.lojavirtual.dao.PessoaDAO;
import br.com.r8info.lojavirtual.model.Pessoa;
import br.com.r8info.lojavirtual.security.business.exception.PessoaNaoAutenticadoException;
import br.com.r8info.lojavirtual.security.business.model.PessoaAutenticada;
import br.com.r8info.lojavirtual.security.business.utils.PasswordUtils;
import br.com.r8info.lojavirtual.security.model.RoleAuthority;

@Service
public class AcessoSB extends BaseSB {
	
	public PessoaDAO pessoaDAO;

	@Override
	protected void postConstructImpl() {
		pessoaDAO = getDAO(PessoaDAO.class);
	}
	
	private PessoaAutenticada afterAuthentication(Pessoa pessoa) {
		Set<RoleAuthority> authorities = new HashSet<RoleAuthority>();
		authorities.add(new RoleAuthority(pessoa.getTipo()));
		return new PessoaAutenticada(pessoa.getId(), 
									 pessoa.getNome(),
									 pessoa.getCpfCnpj(), 
									 pessoa.getTipo(),
									 authorities);
	}

	public PessoaAutenticada autenticar(String email, String senha) throws PessoaNaoAutenticadoException {
		Pessoa pessoa = pessoaDAO.findByEmailAndSenha(email,
				PasswordUtils.criptografarMD5(senha));
		if (pessoa == null) {
			throw new PessoaNaoAutenticadoException();
		}
		return afterAuthentication(pessoa);
	}

}

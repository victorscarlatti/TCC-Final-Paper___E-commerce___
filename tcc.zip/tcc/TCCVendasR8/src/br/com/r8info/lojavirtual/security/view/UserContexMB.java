package br.com.r8info.lojavirtual.security.view;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

import lombok.Getter;
import lombok.Setter;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;

import br.com.r8info.lojavirtual.common.view.BaseMB;
import br.com.r8info.lojavirtual.enums.TipoPessoaEnum;
import br.com.r8info.lojavirtual.security.business.model.PessoaAutenticada;
import br.com.r8info.lojavirtual.view.CarrinhoMB;

@ManagedBean
@SessionScoped
@Getter
@Setter
public class UserContexMB extends BaseMB {
	public static final String SK_USER_CTX = "user_context";

	private String email;
	private String senha;
	private boolean logado;
	private TipoPessoaEnum tipoPessoa;
	
	private String url = PAGE_LOGIN;
	
	@ManagedProperty(name = "authenticationManager", value = "#{authenticationManager}")
	private AuthenticationManager authenticationManager;

	@ManagedProperty(value = "#{carrinhoMB}")
	private CarrinhoMB carrinhoMB;
	
	public void doPrepareLoad() {
		if (!getFacesContext().isPostback()) {
			String value = (String) getRequestParameterMap("auto");
			if (value != null && value.equalsIgnoreCase("true")) {
				showInsertMessage();
			}
		}
	}
	
	

	private void afterAuthentication() {
		PessoaAutenticada pessoaAutenticada = getCurrentUser();
		email = pessoaAutenticada.getUsername();
		senha = null;
		logado = true;
		tipoPessoa = pessoaAutenticada.getTipoPessoa();
	}

	public void doLogin() {
		url = PAGE_INTERNO + "/minha-conta.xhtml";
		try {
			UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
					this.getEmail(), this.getSenha());
			SecurityContextHolder.getContext().setAuthentication(
					authenticationManager.authenticate(authentication));
			afterAuthentication();

			if (TipoPessoaEnum.ADMINISTRADOR.equals(tipoPessoa)) {
				url = PAGE_INTERNO + "/minha-conta-adm.xhtml";
			} else if (carrinhoMB.temItens()) {
				url = PAGE_INTERNO + "/pedido-fechado.xhtml";
			}
			redirect(url);
		} catch (AuthenticationException e) {
			showErrorMessage(e.getMessage());
		}
	}
}
